function generateRedirect() {
  const realLink = document.getElementById('realLink').value.trim();
  if (!realLink) {
    alert("Please enter a URL");
    return;
  }

  const fakeID = makeRandomID();
  const fakeURL = `https://link.done/${fakeID}`;

  document.getElementById('output').innerHTML = `
    <p id="maskedLink">${fakeURL}</p>
    <button onclick="copyToClipboard('${fakeURL}')">Copy Link</button>
  `;
}

function makeRandomID(length = 6) {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    alert("Link copied to clipboard!");
  }, () => {
    alert("Failed to copy!");
  });
}